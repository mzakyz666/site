<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
    <!-- Site meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title; ?></title>
    <link href="https://repo.errorcybernews.com/resources/themes/bootstrap/img/favicon.png" rel="icon" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/trucss.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
</head>
<body>
<div class="col-12">
    <div class="row">
        <nav>
            <div class="col-4">
                <button class="col-hidden button button-menu">MENU</button>
                <div class="logo">
                    <a href="<?= base_url(); ?>"><img src="https://repo.errorcybernews.com/logo-e404cn-white.png" width="150px"></a>
                </div>
            </div>
            <div class="col-8">
                <ul class="list-inline text-right menu">
                    <div class="menu-body">
                        <button class="button button-close"><i class="fa fa-times"></i> </button>
                        <li><a href="<?= base_url(); ?>">Url Shortener</a> | </li>
                        <li><a href="<?= base_url(); ?>expand-url">Url Expander</a> | </li>
                        <li><a href="https://about.errorcybernews.com" target="_blank">About Us</a> | </li>
                    </div>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="contain">
