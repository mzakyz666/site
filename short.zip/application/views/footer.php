<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
</div>

<footer class="text-white">
    <div class="contain mb0">
        <div class="row">
            <div class="col-6">
                <p class="text-left">
                    <a href="#"><?= $back_top; ?></a>
                </p>
            </div>
            <div class="col-6">
                <p class="text-right">
                    Made with <i class="fa fa-heart"></i> in Tasikmalaya, West Java - Indonesia<br>
                    <span>Powered by <a href="https://muhammadzakyzulfiqor.xyz" target="_blank" title="kernel-panic" rel="designer"><span>kernel-panic</span></a> featuring <a href="https://www.facebook.com/lanhasta" target="_blank" title="crypton-venom" rel="designer"><span>crypton-venom</span></a></span><br>
                    <a href="https://www.facebook.com/errorcybernews" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/errorcybernews" target="_blank"><i class="fa fa-instagram"></i></a>
                    <a href="https://t.me/errorcybernews" target="_blank"><i class="fa fa-telegram"></i></a>
                    <a href="https://flickr.com/photos/149234463@N08/albums" target="_blank"><i class="fa fa-flickr"></i></a>
                    <a href="https://www.youtube.com/c/Error404CyberNews" target="_blank"><i class="fa fa-youtube"></i></a>
                    <a href="https://github.com/errorcybernews" target="_blank"><i class="fa fa-github"></i></a>
                    <a href="https://www.paypal.me/error404cybernews" target="_blank"><i class="fa fa-paypal"></i></a>
                    <a href="https://about.errorcybernews.com/#contact" target="_blank"><i class="fa fa-envelope"></i></a>
                </p>
            </div>
        </div>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
<!-- Menu -->
<script type="text/javascript">
    $( ".button-menu" ).click(function() {
        $(".menu-body").show();
    });
    $( ".button-close" ).click(function() {
        $(".menu-body").hide();
    });
    $(window).resize(function() {
        if ($(window).width() > 768) {
            $(".menu-body").show();
        }
        else {
            $(".menu-body").hide();
        }
    });
</script>
<!-- Copy URL -->
<script type="text/javascript">
    $('.copy-btn').on("click", function(){
        value = $(this).data('clipboard-text'); //Upto this I am getting value

        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(value).select();
        document.execCommand("copy");
        $temp.remove();
        $(".copy-message").show();
    })
</script>
</body>
</html>

