<?php
$lang["title"] = "Installation of Url Shortener Php / Sql";
$lang["installation"] = "Installation";
$lang["what_is_it"] = "What is it ?";
$lang["description"] = "Url Shortener is a free PHP / Mysql script buid with CodeIgniter 3.";
$lang["download"] = "Download";
$lang["download_url_shortener"] = "Download Url Shortener v0.1";
$lang["step_1"] = 'Upload files on your server';
$lang["step_2"] = 'Edit application/config/config.php file :';
$lang["step_3"] = 'Edit application/config/database.php file (line 78) :';
$lang["step_4"] = 'Upload Database';
$lang["step_4_description"] = 'Upload application/install/database.sql file or execute this following sql request.';
