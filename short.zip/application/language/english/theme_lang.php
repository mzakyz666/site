<?php
$lang["back_top"] = "Back to top";
$lang["created_with"] = "Created with";
$lang["by"] = "by";
