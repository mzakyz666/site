<?php
$lang["title_expand_page"] = "Url Expander - Error 404 Cyber News";
$lang["title_shortener_page"] = "Url Shortener - Error 404 Cyber News";
$lang["url_expander"] = "Url Expander";
$lang["url_shortener"] = "Url Shortener";
$lang["past_your_link_to_shorten"] = "Paste your link to shorten it";
$lang["shorten"] = "Shorten";
$lang["last_urls_shorten"] = "Last Urls Shorten";
$lang["long_url"] = "Long Url";
$lang["short_url"] = "Short Url";
$lang["copy"] = "Copy";
$lang["url_copied"] = "Url copied in clipboard";
$lang["expand"] = "Expand";
$lang["last_urls_expanded"] = "Last Urls Expanded";
$lang["past_your_link_to_expand"] = "Paste your link to expand it";
$lang["url_not_redirected"] = "This url is not redirected";
